import React from 'react'

const RoomsBase = () => {
  return (
    <div>RoomsBase</div>
  )
}

export default RoomsBase