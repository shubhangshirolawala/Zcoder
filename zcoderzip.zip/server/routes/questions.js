const express = require("express");
const router = express.Router();
const {
  getAllBookmarks,
  getAllQuestions,
  createQuestion,
  deleteBookmark,
} = require("../controllers/questions");

router.post("/deleteBookmark",deleteBookmark);
router.post("/getAllBookmarks", getAllBookmarks);
router.post("/getAllQuestions", getAllQuestions);
router.post("/createQuestion", createQuestion);

module.exports = router;
